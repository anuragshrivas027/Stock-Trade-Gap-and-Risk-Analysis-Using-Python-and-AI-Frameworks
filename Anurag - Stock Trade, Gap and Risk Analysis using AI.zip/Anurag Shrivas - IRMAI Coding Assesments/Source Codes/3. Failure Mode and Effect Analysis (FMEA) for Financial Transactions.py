import sys
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from py2neo import Graph, Node, Relationship

# Handle missing requests module gracefully
try:
    import requests
except ImportError as e:
    print(f"Missing module '{e.name}'. Install it using: pip install {e.name}")
    sys.exit(1)

class FinancialFMEA:
    def __init__(self, neo4j_uri="neo4j+s://8cd7a109.databases.neo4j.io:7687", neo4j_user="neo4j", neo4j_password="yjQrXmTA_JB63Vca9YPh3VZMYqcHnkL-xOVDlDKTz8s"):
        self.num_transactions = 100
        self.transaction_types = ["Deposit", "Withdrawal", "Transfer", "Payment"]
        self.fmea_data = None
        
        try:
            self.graph = Graph(neo4j_uri, auth=(neo4j_user, neo4j_password))
            self.graph.run("RETURN 1")  # Test query
        except Exception:
            self.graph = None
    
    def collect_data(self, csv_file=None):
        if csv_file:
            try:
                self.fmea_data = pd.read_csv(csv_file)
            except Exception:
                return
        else:
            np.random.seed(42)
            data = {
                "Transaction_ID": range(1, self.num_transactions + 1),
                "Transaction_Type": np.random.choice(self.transaction_types, self.num_transactions),
                "Amount": np.random.uniform(10, 10000, self.num_transactions),
                "Risk_Score": np.random.randint(1, 10, self.num_transactions),
                "Timestamp": pd.date_range(start="2025-02-01", periods=self.num_transactions, freq="h"),
            }
            self.fmea_data = pd.DataFrame(data)
    
    def construct_graph(self):
        if self.graph is None:
            return
        self.graph.run("MATCH (n) DETACH DELETE n")
        transaction_nodes = {}
        for _, row in self.fmea_data.iterrows():
            transaction_node = Node("Transaction", Transaction_ID=int(row["Transaction_ID"]), Transaction_Type=row["Transaction_Type"], 
                                    Amount=row["Amount"], Risk_Score=row["Risk_Score"], Timestamp=str(row["Timestamp"]))
            self.graph.create(transaction_node)
            transaction_nodes[row["Transaction_ID"]] = transaction_node
        for i in range(1, len(transaction_nodes)):
            self.graph.create(Relationship(transaction_nodes[i], "NEXT_TRANSACTION", transaction_nodes[i + 1]))
    
    def analyze_risk(self):
        if self.fmea_data is None:
            return
        self.fmea_data["Risk_Category"] = "Low"
        self.fmea_data.loc[self.fmea_data["Risk_Score"] >= 5, "Risk_Category"] = "Moderate"
        self.fmea_data.loc[self.fmea_data["Risk_Score"] >= 8, "Risk_Category"] = "High"
    
    def generate_report(self):
        risk_counts = self.fmea_data["Risk_Category"].value_counts()
        print("\nFMEA Risk Summary Report")
        print("----------------------------")
        print(risk_counts)
    
    def visualize_data(self):
        if self.fmea_data is None:
            return
        fig = go.Figure()
        
        # Risk Score as Bar Graph
        fig.add_trace(go.Bar(x=self.fmea_data["Timestamp"], y=self.fmea_data["Risk_Score"],
                             name='Risk Score', marker_color='red', opacity=0.6))
        
        # Amount as Bar Graph
        fig.add_trace(go.Bar(x=self.fmea_data["Timestamp"], y=self.fmea_data["Amount"],
                             name='Transaction Amount', marker_color='blue', opacity=0.8, yaxis='y2'))
        
        fig.update_layout(
            title="Financial Transactions FMEA Analysis",
            xaxis_title="Timestamp",
            yaxis=dict(title="Risk Score", side="left"),
            yaxis2=dict(title="Transaction Amount", overlaying="y", side="right"),
            template="plotly_white",
            height=600,
            width=1000,
            font=dict(family="Arial", size=14, color="black"),
            legend=dict(bgcolor="rgba(255,255,255,0.5)"),
            annotations=[
                dict(x=self.fmea_data["Timestamp"].iloc[-1],
                     y=self.fmea_data["Risk_Score"].max(),
                     text="Red bars indicate Risk Score",
                     showarrow=True,
                     arrowhead=2,
                     font=dict(size=12, color="black")),
                dict(x=self.fmea_data["Timestamp"].iloc[-1],
                     y=self.fmea_data["Amount"].max(),
                     text="Blue bars indicate Transaction Amount",
                     showarrow=True,
                     arrowhead=2,
                     font=dict(size=12, color="black"))
            ]
        )
        
        fig.show()

if __name__ == "__main__":
    analysis = FinancialFMEA(neo4j_uri="neo4j+s://8cd7a109.databases.neo4j.io:7687", neo4j_user="neo4j", neo4j_password="yjQrXmTA_JB63Vca9YPh3VZMYqcHnkL-xOVDlDKTz8s")
    analysis.collect_data()
    analysis.construct_graph()
    analysis.analyze_risk()
    analysis.generate_report()
    analysis.visualize_data()
