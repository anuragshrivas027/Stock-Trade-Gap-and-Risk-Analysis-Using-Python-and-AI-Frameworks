import sys
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from py2neo import Graph, Node, Relationship

# Handle missing requests module gracefully
try:
    import requests
except ImportError as e:
    print(f"Missing module '{e.name}'. Install it using: pip install {e.name}")
    sys.exit(1)

class StockTradeGapAnalysis:
    def __init__(self, neo4j_uri="neo4j+s://8cd7a109.databases.neo4j.io:7687", neo4j_user="neo4j", neo4j_password="yjQrXmTA_JB63Vca9YPh3VZMYqcHnkL-xOVDlDKTz8s"):
        self.num_trades = 100
        self.stock_symbols = ["AAPL", "MSFT"]
        self.trade_data = None
        
        try:
            self.graph = Graph(neo4j_uri, auth=(neo4j_user, neo4j_password))
            self.graph.run("RETURN 1")  # Test query
        except Exception:
            self.graph = None
    
    def collect_data(self, api_url=None, csv_file=None):
        if api_url:
            try:
                response = requests.get(api_url)
                data = response.json()
                self.trade_data = pd.DataFrame(data)
            except Exception:
                return
        elif csv_file:
            try:
                self.trade_data = pd.read_csv(csv_file)
            except Exception:
                return
        else:
            np.random.seed(42)
            data = {
                "Trade_ID": range(1, self.num_trades + 1),
                "Stock_Symbol": np.random.choice(self.stock_symbols, self.num_trades),
                "Trade_Volume": np.random.uniform(10000, 500000, self.num_trades),
                "Price": np.round(np.random.uniform(100, 500, self.num_trades), 2),
                "Timestamp": pd.date_range(start="2025-02-01", periods=self.num_trades, freq="h"),
            }
            self.trade_data = pd.DataFrame(data)
    
    def construct_graph(self):
        if self.graph is None:
            return
        self.graph.run("MATCH (n) DETACH DELETE n")
        trade_nodes = {}
        for _, row in self.trade_data.iterrows():
            trade_node = Node("Trade", Trade_ID=int(row["Trade_ID"]), Stock_Symbol=row["Stock_Symbol"], 
                              Trade_Volume=row["Trade_Volume"], Price=row["Price"], Timestamp=str(row["Timestamp"]))
            self.graph.create(trade_node)
            trade_nodes[row["Trade_ID"]] = trade_node
        for i in range(1, len(trade_nodes)):
            self.graph.create(Relationship(trade_nodes[i], "NEXT_TRADE", trade_nodes[i + 1]))
    
    def gap_analysis(self):
        if self.trade_data is None:
            return
        self.trade_data["Time_Gap"] = self.trade_data["Timestamp"].diff().dt.total_seconds() / 3600
        self.trade_data["Price_Gap"] = self.trade_data["Price"].diff().abs()
        
        self.trade_data["Gap_Flag"] = "No Gap"
        self.trade_data.loc[self.trade_data["Time_Gap"] > 2, "Gap_Flag"] = "Missing Trade"
        self.trade_data.loc[self.trade_data["Price_Gap"] > 10, "Gap_Flag"] = "Unusual Price Jump"
    
    def generate_report(self):
        gap_counts = self.trade_data["Gap_Flag"].value_counts()
        print("\nTrade Gap Summary Report")
        print("----------------------------")
        print(gap_counts)
    
    def visualize_data(self):
        if self.trade_data is None:
            return
        frames = []
        for i in range(1, len(self.trade_data)):
            frame = go.Frame(
                data=[
                    go.Bar(x=self.trade_data["Timestamp"][:i], y=self.trade_data["Trade_Volume"][:i],
                           name='Trade Volume', marker_color='red', opacity=0.6),
                    go.Bar(x=self.trade_data["Timestamp"][:i], y=self.trade_data["Price"][:i],
                           name='Stock Price', marker_color='blue', opacity=0.8, yaxis='y2')
                ],
                name=str(i)
            )
            frames.append(frame)
        
        fig = go.Figure(
            data=[
                go.Bar(x=self.trade_data["Timestamp"], y=self.trade_data["Trade_Volume"],
                       name='Trade Volume', marker_color='red', opacity=0.6),
                go.Bar(x=self.trade_data["Timestamp"], y=self.trade_data["Price"],
                       name='Stock Price', marker_color='blue', opacity=0.8, yaxis='y2')
            ],
            frames=frames
        )
        
        fig.update_layout(
            annotations=[
                dict(x=self.trade_data["Timestamp"].iloc[-1],
                     y=self.trade_data["Trade_Volume"].max(),
                     text="Red bars indicate Trade Volume",
                     showarrow=True,
                     arrowhead=2,
                     font=dict(size=12, color="black")),
                dict(x=self.trade_data["Timestamp"].iloc[-1],
                     y=self.trade_data["Price"].max(),
                     text="Blue bars indicate Stock Price",
                     showarrow=True,
                     arrowhead=2,
                     font=dict(size=12, color="black"))
            ],
            title="Stock Trade Gap Analysis",
            xaxis_title="Timestamp",
            yaxis=dict(title="Trade Volume", side="left"),
            yaxis2=dict(title="Stock Price", overlaying="y", side="right"),
            template="plotly_white",
            height=600,
            width=1000,
            font=dict(family="Arial", size=14, color="black"),
            legend=dict(bgcolor="rgba(255,255,255,0.5)"),
            updatemenus=[{
                'buttons': [
                    {'args': [None, {'frame': {'duration': 500, 'redraw': True}, 'fromcurrent': True}],
                     'label': "Play", 'method': "animate"},
                    {'args': [[None], {'frame': {'duration': 0, 'redraw': True}, 'mode': "immediate", 'transition': {'duration': 0}}],
                     'label': "Pause", 'method': "animate"}
                ],
                'direction': "left",
                'pad': {"r": 10, "t": 87},
                'showactive': False,
                'type': "buttons",
                'x': 0.1,
                'xanchor': "right",
                'y': 1.1,
                'yanchor': "top"
            }]
        )
        
        fig.show()

if __name__ == "__main__":
    analysis = StockTradeGapAnalysis(neo4j_uri="neo4j+s://8cd7a109.databases.neo4j.io:7687", neo4j_user="neo4j", neo4j_password="yjQrXmTA_JB63Vca9YPh3VZMYqcHnkL-xOVDlDKTz8s")
    analysis.collect_data()
    analysis.construct_graph()
    analysis.gap_analysis()
    analysis.generate_report()
    analysis.visualize_data()
