import sys
import time
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
import plotly.graph_objects as go
from py2neo import Graph, Node, Relationship

# Handle missing requests module gracefully
try:
    import requests
    import websocket
except ImportError as e:
    print(f"Missing module '{e.name}'. Install it using: pip install {e.name}")
    sys.exit(1)

class StockTradeAnalysis:
    def __init__(self, neo4j_uri="bolt://localhost:7687", neo4j_user="neo4j", neo4j_password="your_password"):
        self.num_trades = 100
        self.currency_pairs = ["EUR/USD", "GBP/USD"]
        self.fx_trades_df = None

        try:
            self.graph = Graph("neo4j+s://8cd7a109.databases.neo4j.io:7687", auth=("neo4j", "yjQrXmTA_JB63Vca9YPh3VZMYqcHnkL-xOVDlDKTz8s"))
            self.graph.run("RETURN 1")  # Test query
        except Exception:
            self.graph = None
    
    def collect_data(self, api_url=None, csv_file=None, live_stream=False):
        if api_url:
            try:
                response = requests.get(api_url)
                data = response.json()
                self.fx_trades_df = pd.DataFrame(data)
            except Exception:
                return
        elif csv_file:
            try:
                self.fx_trades_df = pd.read_csv(csv_file)
            except Exception:
                return
        elif live_stream:
            self.stream_live_data()
        else:
            np.random.seed(42)
            data = {
                "Trade_ID": range(1, self.num_trades + 1),
                "Currency_Pair": np.random.choice(self.currency_pairs, self.num_trades),
                "Trade_Volume": np.random.uniform(10000, 500000, self.num_trades),
                "Price": np.round(np.random.uniform(1.1, 1.5, self.num_trades), 4),
                "Timestamp": pd.date_range(start="2025-02-01", periods=self.num_trades, freq="h"),
            }
            self.fx_trades_df = pd.DataFrame(data)
    
    def visualize_data(self):
        if self.fx_trades_df is None:
            return
        frames = []
        for i in range(1, len(self.fx_trades_df)):
            frame = go.Frame(
                data=[
                    go.Scatter(x=self.fx_trades_df["Timestamp"][:i], y=self.fx_trades_df["Trade_Volume"][:i],
                               mode='lines+markers', name='Trade Volume', line=dict(color='blue')),
                    go.Scatter(x=self.fx_trades_df["Timestamp"][:i], y=self.fx_trades_df["Price"][:i],
                               mode='lines+markers', name='Price', line=dict(color='red'))
                ],
                name=str(i)
            )
            frames.append(frame)
        
        fig = go.Figure(
            data=[
                go.Scatter(x=self.fx_trades_df["Timestamp"], y=self.fx_trades_df["Trade_Volume"],
                           mode='lines+markers', name='Trade Volume', line=dict(color='blue')),
                go.Scatter(x=self.fx_trades_df["Timestamp"], y=self.fx_trades_df["Price"],
                           mode='lines+markers', name='Price', line=dict(color='red'))
            ],
            frames=frames
        )
        
        fig.update_layout(
            title="Stock Trade Analysis",
            xaxis_title="Timestamp",
            yaxis_title="Value",
            template="plotly_dark",
            height=600,
            width=1000,
            font=dict(family="Arial", size=14, color="yellow"),
            legend=dict(bgcolor="rgba(255,255,255,0.5)"),
            annotations=[
                dict(x=self.fx_trades_df["Timestamp"].iloc[-1],
                     y=self.fx_trades_df["Trade_Volume"].max(),
                     text="Blue line indicates Trade Volume",
                     showarrow=True,
                     arrowhead=2,
                     font=dict(size=12, color="yellow")),
                dict(x=self.fx_trades_df["Timestamp"].iloc[-1],
                     y=self.fx_trades_df["Price"].max(),
                     text="Red line indicates Price",
                     showarrow=True,
                     arrowhead=2,
                     font=dict(size=12, color="white"))
            ],
            updatemenus=[{
                'buttons': [
                    {'args': [None, {'frame': {'duration': 500, 'redraw': True}, 'fromcurrent': True}],
                     'label': "Play", 'method': "animate"},
                    {'args': [[None], {'frame': {'duration': 0, 'redraw': True}, 'mode': "immediate", 'transition': {'duration': 0}}],
                     'label': "Pause", 'method': "animate"}
                ],
                'direction': "left",
                'pad': {"r": 10, "t": 87},
                'showactive': False,
                'type': "buttons",
                'x': 0.1,
                'xanchor': "right",
                'y': 1.1,
                'yanchor': "top"
            }]
        )
        
        fig.show()

if __name__ == "__main__":
    analysis = StockTradeAnalysis(neo4j_uri="neo4j+s://8cd7a109.databases.neo4j.io:7687", neo4j_user="neo4j", neo4j_password="yjQrXmTA_JB63Vca9YPh3VZMYqcHnkL-xOVDlDKTz8s")
    analysis.collect_data(live_stream=False)
    analysis.visualize_data()
